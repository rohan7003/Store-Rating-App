import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { query } from './src/lib/db.js';

// Load environment variables from the .env file
dotenv.config();

// Import your router modules
import authRoutes from './src/routes/auth.js';
import adminRoutes from './src/routes/admin.js';
import ownerRoutes from './src/routes/owner.js';
import storesRoutes from './src/routes/stores.js';

const app = express();
const PORT = process.env.PORT || 4000;

// Middleware
app.use(cors());
app.use(express.json());

// Basic test route
app.get('/', (req, res) => {
    res.send('API is running!');
});

// Mount the routers to their respective paths
app.use('/auth', authRoutes);
app.use('/admin', adminRoutes);
app.use('/owner', ownerRoutes);
app.use('/stores', storesRoutes);

// 404 Not Found handler
app.use((req, res, next) => {
    res.status(404).json({ message: 'Not found' });
});

// Function to test the database connection and start the server
async function startServer() {
    try {
        await query('SELECT 1');
        console.log('✅ Database connected successfully.');
    } catch (error) {
        console.error('❌ Database connection failed:', error.message);
        // It's a good practice to exit if the DB connection is critical
        // process.exit(1); 
    }

    // Start the server after the database check
    app.listen(PORT, () => {
        console.log(`Server is running on port ${PORT}`);
    });
}

// Call the function to start the application
startServer();